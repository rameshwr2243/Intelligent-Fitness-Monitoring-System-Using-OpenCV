
AI Puppet Cartoon v1
-----------------------
Track your body & hands in real-time and see a cartoon puppet mirror your motion!

Features:
- Real-time body + hand tracking (MediaPipe)
- Cartoon puppet overlay (head, body, hands)
- Clean white background for demo clarity

How to Run:
1. pip install -r requirements.txt
2. python main_puppet_v1.py

Controls:
ESC — Quit

Made for AI & Data Science students
Perfect for showcasing Computer Vision, MediaPipe, and OpenCV integration.
